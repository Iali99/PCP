MRSW ::
TO COMPILE : "g++ -std=c++11 -pthread mrsw-cs16btech11019.cpp -o mrsw"
TO RUN : "./mrsw < inp-params.txt"

MRMW ::
TO COMPILE : "g++ -std=c++11 -pthread mrmw-cs16btech11019.cpp -o mrmw"
TO RUN : "./mrmw < inp-params.txt"

File Log-MRSW.txt : Log file for MRSW implementation
File Log-MRMW.txt : Log file for MRMW implementation
