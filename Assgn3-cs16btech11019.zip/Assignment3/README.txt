TO COMPILE : "g++ -std=c++11 -pthread Assgn3-src.cpp -o assgn3"
TO RUN : "./assgn3 < inp-params.txt"

File Log-Output.txt : Log file for our implementation
File inbuilt-Log-output.txt : Log file for inbuilt implementation
